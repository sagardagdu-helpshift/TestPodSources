Helpshift('open');

var widgetToggleEventHandler = function (data) {
    window.webkit.messageHandlers.widgetToggle.postMessage(data);
}
Helpshift("addEventListener", "widgetToggle", widgetToggleEventHandler);

var localStorageSetEventHandler = function (data) {
    window.webkit.messageHandlers.onSetLocalStorageData.postMessage(data);
}
Helpshift("addEventListener",  "onSetLocalStorageData", localStorageSetEventHandler);

var localStorageRemovalEventHandler = function (data) {
    window.webkit.messageHandlers.onRemoveLocalStorageData.postMessage(data);
}
Helpshift("addEventListener",  "onRemoveLocalStorageData", localStorageRemovalEventHandler);

var globalApiEventHandler = function (data) {
    window.webkit.messageHandlers.globalApiEvent.postMessage(data);
}
Helpshift("addEventListener", "globalApiEvent", globalApiEventHandler);

var uiConfigChangeHandler = function (data) {
    window.webkit.messageHandlers.onUiConfigChange.postMessage(data);
}
Helpshift("addEventListener", "onUiConfigChange", uiConfigChangeHandler);

var pushTokenSyncHandler = function (data) {
    window.webkit.messageHandlers.onPushTokenSync.postMessage(data);
}
Helpshift("addEventListener", "onPushTokenSync", pushTokenSyncHandler);

var userAuthFailureHandler = function (data) {
    window.webkit.messageHandlers.onUserAuthFailure.postMessage(data)
}
Helpshift("addEventListener", "onUserAuthFailure", onUserAuthFailureHandler);

var anonymousUserRemovedHandler = function () {
    window.webkit.messageHandlers.onRemoveAnonymousUser.postMessage()
}
Helpshift("addEventListener", "onRemoveAnonymousUser", anonymousUserRemovedHandler);
