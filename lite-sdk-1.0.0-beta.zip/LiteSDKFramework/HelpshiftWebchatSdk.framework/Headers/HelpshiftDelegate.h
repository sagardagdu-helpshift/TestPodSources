//
//  HelpshiftWebchatDelegate.h
//  HelpshiftWebchatSdk
//
//  Copyright © 2019 Helpshift. All rights reserved.
//

#ifndef HelpshiftWebchatDelegate_h
#define HelpshiftWebchatDelegate_h

typedef NS_ENUM (NSUInteger, HelpshiftAuthenticationFailureReason)
{
    HelpshiftAuthenticationFailureReasonAuthTokenNotProvided = 0,
    HelpshiftAuthenticationFailureReasonInvalidAuthToken,
};

@protocol HelpshiftDelegate <NSObject>

/**
 * Delegate method that gets called when events are received from webchat. For possible events,
 * refer : https://developers.helpshift.com/web-chat/api/#events
 *
 * @param eventName The name of the event
 * @param data The data received from the event if any.
 */
- (void) handleHelpshiftEvent:(nonnull NSString *)eventName withData:(nullable NSDictionary *)data;

/**
 * Optional delegate method that gets called when the user authentication fails.
 * Whenever you receive this call, You should be calling the login API with valid authToken.
 *
 * @param reason The reason for authentication failure
 *
 */
- (void) authenticationFailedForUserWithReason:(HelpshiftAuthenticationFailureReason)reason;
@end

#endif /* HelpshiftWebchatDelegate_h */
