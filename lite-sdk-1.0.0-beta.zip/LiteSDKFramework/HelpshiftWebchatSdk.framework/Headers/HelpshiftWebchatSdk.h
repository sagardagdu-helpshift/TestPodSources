//
//  HelpshiftWebchatSdk.h
//  HelpshiftWebchatSdk
//
//  Created by rhishikesh on 26/07/19.
//  Copyright © 2019 Helpshift. All rights reserved.
//

#import <UIKit/UIKit.h>

// ! Project version number for HelpshiftWebchatSdk.
FOUNDATION_EXPORT double HelpshiftWebchatSdkVersionNumber;

// ! Project version string for HelpshiftWebchatSdk.
FOUNDATION_EXPORT const unsigned char HelpshiftWebchatSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HelpshiftWebchatSdk/PublicHeader.h>

#import "Helpshift.h"

