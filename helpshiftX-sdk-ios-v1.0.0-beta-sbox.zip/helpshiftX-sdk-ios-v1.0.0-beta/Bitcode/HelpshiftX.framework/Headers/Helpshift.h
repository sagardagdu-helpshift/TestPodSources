//
//  Helpshift.h
//  HelpshiftX
//
//  Created by rhishikesh on 26/07/19.
//  Copyright © 2019 Helpshift. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "HelpshiftDelegate.h"
NS_ASSUME_NONNULL_BEGIN

static NSString *const HelpshiftUserName = @"userName";
static NSString *const HelpshiftUserIdentifier = @"userId";
static NSString *const HelpshiftUserEmail = @"userEmail";
static NSString *const HelpshiftUserAuthToken = @"userAuthToken";


@interface Helpshift : NSObject

@property (nonatomic, weak) id<HelpshiftDelegate> delegate;

/** Returns an instance of Helpshift
 *
 * When using Helpshift, use below method to get the singleton instance of this class.
 *
 */
+ (Helpshift *) sharedInstance;

/** Initialize helpshift support
 *
 * When initializing Helpshift you must pass these two tokens. You initialize Helpshift by adding the following lines in the implementation file for your app delegate, ideally at the top of application:didFinishLaunchingWithOptions. This method can throw the InstallException asynchronously if the install keys are not in the correct format.
 *  @param platformId This is your platform id API Key
 *  @param domain This is your domain name
 *  @param config This is the config dictionary represents the configuration parameters for the installation
 */
+ (void) installWithPlatformId:(NSString *)platformId
    domain:(NSString *)domain
    config:(NSDictionary *)config;

/**
 *  This method pauses/restarts the display in-app notification.
 *
 *  @param shouldPauseInAppNotification the boolean value to pause/restart inapp nofitications
 */
+ (void) pauseDisplayOfInAppNotification:(BOOL)shouldPauseInAppNotification;

/**
 * Logs in a given user. This method accepts an NSDictionary whose keys are one of @c HelpshiftUserName, @c HelpshiftUserIdentifier, @c HelpshiftUserEmail, @c HelpshiftUserAuthToken
 * These are string constants defined in Helpshift.h file. The following describes the values for the above keys:
 *
 * @param userDetails The @c NSDictionary representing the user details
 */
+ (void) loginUser:(NSDictionary<NSString *, NSString *> *)userDetails;

/**
 * Logs out the previously logged in user
 */
+ (void) logout;

/**
 * Call this API if you need to clear the anonymous user data on login
 */
+ (void) clearAnonymousUserOnLogin;

/**
 * Shows the helpshift support conversation screen.
 *
 * @param viewController The @c UIViewController on which the conversation screen is to be shown
 * @param config An @c NSDictionary which represents the configuration that needs to be set to the conversation.
 */
+ (void) showConversationWith:(UIViewController *)viewController
    config:(NSDictionary *)config;

/** Change the SDK language. By default, the device's prefered language is used.
 * The call will fail in the following cases :
 * 1. If a Helpshift session is already active at the time of invocation
 * 2. Language code is incorrect
 * @param languageCode the string representing the language code. For example, use 'fr' for French.
 */
+ (void) setLanguage:(NSString *)languageCode;

/** Register the deviceToken to enable push notifications
 * To enable push notifications in the Helpshift iOS SDK, set the Push Notifications’ deviceToken using this method inside your application:didRegisterForRemoteNotificationsWithDeviceToken application delegate.
 *  @param deviceToken The deviceToken received from the push notification servers.
 */
+ (void) registerDeviceToken:(NSData *)deviceToken;

/**
 *  Pass along the userInfo dictionary (received with a UNNotification) for the Helpshift SDK to handle
 *  @param userInfo   dictionary contained in the UNNotification object received in App delegate.
 *  @param viewController The viewController on which you want the Helpshift SDK stack to be shown
 *  @param isAppLaunch    A boolean indicating whether the app was lanuched from a killed state. This parameter should ideally only be true in case when called from app's didFinishLaunchingWithOptions delegate.
 *  @return BOOL value indicating whether Helpshift handled this notification.
 */
+ (BOOL) handleNotificationWithUserInfoDictionary:(NSDictionary *)userInfo isAppLaunch:(BOOL)isAppLaunch withController:(UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
